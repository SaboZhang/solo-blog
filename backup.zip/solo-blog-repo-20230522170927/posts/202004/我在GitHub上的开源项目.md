title: 我在 GitHub 上的开源项目
date: '2020-04-12 22:51:35'
updated: '2020-04-12 22:51:35'
tags: [开源, GitHub]
permalink: /my-github-repos
---
<!-- 该页面会被定时任务自动覆盖，所以请勿手工更新 -->
<!-- 如果你有更漂亮的排版方式，请发 issue 告诉我们 -->

### 1. [RimeConfig](https://github.com/SaboZhang/RimeConfig) <kbd title="主要编程语言"></kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/SaboZhang/RimeConfig/watchers "关注数")&nbsp;&nbsp;[⭐️`5`](https://github.com/SaboZhang/RimeConfig/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/SaboZhang/RimeConfig/network/members "分叉数")</span>

Rime 为简体中文用户专门提供了袖珍简化字拼音，但是默认方案直接使用不够方便。本项目提供了作者个人使用的配置文件，帮助有意如此使用的用户快速上手。同时也作为自己配置文件的一个同步仓库。



---

### 2. [solo-blog](https://github.com/SaboZhang/solo-blog) <kbd title="主要编程语言"></kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/SaboZhang/solo-blog/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/SaboZhang/solo-blog/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/SaboZhang/solo-blog/network/members "分叉数")&nbsp;&nbsp;[🏠`https://www.taosugar.com`](https://www.taosugar.com "项目主页")</span>

✍️ 时代幸运星 - 书富如入海，百货皆有！



---

### 3. [WallPoster](https://github.com/SaboZhang/WallPoster) <kbd title="主要编程语言">C#</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/SaboZhang/WallPoster/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/SaboZhang/WallPoster/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/SaboZhang/WallPoster/network/members "分叉数")</span>

影视收藏管理工具，管理本地收藏的影视



---

### 4. [Picture](https://github.com/SaboZhang/Picture) <kbd title="主要编程语言">Shell</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/SaboZhang/Picture/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/SaboZhang/Picture/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/SaboZhang/Picture/network/members "分叉数")</span>





---

### 5. [MovieTools](https://github.com/SaboZhang/MovieTools) <kbd title="主要编程语言">Python</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/SaboZhang/MovieTools/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/SaboZhang/MovieTools/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/SaboZhang/MovieTools/network/members "分叉数")</span>

影片收藏管理工具



---

### 6. [meiduo_shop](https://github.com/SaboZhang/meiduo_shop) <kbd title="主要编程语言">JavaScript</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/SaboZhang/meiduo_shop/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/SaboZhang/meiduo_shop/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/SaboZhang/meiduo_shop/network/members "分叉数")</span>





---

### 7. [about](https://github.com/SaboZhang/about) <kbd title="主要编程语言">CSS</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/SaboZhang/about/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/SaboZhang/about/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/SaboZhang/about/network/members "分叉数")</span>



