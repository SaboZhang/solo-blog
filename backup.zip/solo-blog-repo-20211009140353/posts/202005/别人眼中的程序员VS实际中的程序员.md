title: 别人眼中的程序员 VS 实际中的程序员
date: '2020-05-08 22:29:31'
updated: '2020-05-11 18:00:47'
tags: [程序员]
permalink: /dev
---
  在外行人看来程序员，工资高、福利好、还有专门的程序员鼓励师。高收入低消费，动不动就两三万，年收入三四十万，技术黑客，简直就是人生巅峰，就比如下图这样的。<div style="text-align:center">![UcLVf9HeF1ZVMQB45kDsQ77yqG7JpBonauHHMpWBqkDH1497188029052.jpg](https://img.hacpai.com/file/2020/05/UcLVf9HeF1ZVMQB45kDsQ77yqG7JpBonauHHMpWBqkDH1497188029052-91daa333.jpg)</div>自己眼中的程序员是这样的：<div style="text-align:center">![自己眼中的自己](https://img.hacpai.com/file/2020/05/ide3onkb1-2ab23573.png)</div>

万般皆下品，唯有coding高，一行代码，掌控世界，其他的都是渣渣<div style="text-align:center"> ![一行代码掌控世界](https://img.hacpai.com/file/2020/05/m0gkpesiwl-45dc758d.png)</div>

实际上的程序员是这样的：别人眼中的程序员VS现实中的程序员:wulian::wulian::wulian:<p style="text-align: center"><iframe frameborder="0" src="https://v.qq.com/txp/iframe/player.html?vid=q0559t98o74" allowFullScreen="true" style="width:800px;height:600px;"></iframe></p>
