title: DevOps人员常用的176条Linux命令速查表
date: '2020-05-05 23:20:02'
updated: '2020-05-06 10:34:36'
tags: [Linux]
permalink: /commoncmd
---
  整理的DevOps人员常用的命令罗列出来，建立了一个速查表供大家参考！方便大家进行快速查看，节省搜索时间！



<style>
table td:first-of-type {
width: 106px;
}
table td:nth-of-type(2) {
width: 694px;
}
</style>

### 线上查询及帮助命令



<table class="table table-bordered table-striped table-condensed">
<tr>
<td>man</td>
<td>当你需要查看某个命令的参数时不必到处上网查找，只要man一下即可，命令词典，更复杂的还有info，但不常用</td>
</tr>
<tr>
<td>help</td>
<td> help命令用于显示内置命令的帮助 --help也可使用</td>
</tr>

</table>

### 文件和目录操作命令



<table class="table table-bordered table-striped table-condensed">
<tr>
<td>cd</td>
<td>全拼 change directory，命令用于切换当前工作目录至 dirName(目录参数)。</td>
</tr>
<tr>
<td>cp</td>
<td>全拼 copy，其功能是复制文件或者目录。</td>
</tr>
<tr>
<td>find</td>
<td>查找文件，Linux下非常重要的一条命令，在目录结构中进行搜索</td>
</tr>
<tr>
<td>mkdir</td>
<td>全拼 make directories，建立目录</td>
</tr>
<tr>
<td>mv</td>
<td>全拼 move 用来移动文件或者将文件改名（move (rename) files），经常用来备份文件或者目录。</td>
</tr>
<tr>
<td>pwd</td>
<td>全拼 print working directory，执行pwd指令可立刻得知您目前所在的工作目录的绝对路径名称</td>
</tr>
<tr>
<td>rename</td>
<td>使用指定的替换项替换其名称中的搜索表达式来重命名给定的文件（可批量重命名）</td>
</tr>
<tr>
<td>rm</td>
<td>全拼 remove 用于删除一个文件或者目录。</td>
</tr>
<tr>
<td>rmdir</td>
<td>全拼 remove empty directories，删除空目录。</td>
</tr>
<tr>
<td>touch</td>
<td>修改文件或者目录的时间属性，包括存取时间和更改时间。若文件不存在，系统会建立一个新的文件。</td>
</tr>
<tr>
<td>tree</td>
<td>执行tree指令，它会列出指定目录下的所有文件，包括子目录里的文件（树状结构）</td>
</tr>
<tr>
<td>basename</td>
<td>获取路径中的文件名或路径名，还可以对末尾字符进行删除</td>
</tr>
<tr>
<td>dirname</td>
<td>去除包含绝对路径文件中的文件名，返回目录的部分</td>
</tr>
<tr>
<td>chattr</td>
<td>查看和改变文件目录属性</td>
</tr>
<tr>
<td>lsattr</td>
<td>显示文件属性</td>
</tr>
<tr>
<td>file</td>
<td>辨识文件类型</td>
</tr>
<tr>
<td>md5sum</td>
<td>计算和校验文件MD5值的工具程序</td>
</tr>

</table>

### 查看文件及内容处理命令



<table class="table table-bordered table-striped table-condensed">
<tr>
<td>cat</td>
<td>全拼 concatenate， 命令用于连接文件并打印到标准输出设备上（由第一行开始显示）</td>
</tr>
<tr>
<td>tac</td>
<td>tac是cat的反向拼写，从最后一行倒序显示内容，并将所有内容输出</td>
</tr>
<tr>
<td>more</td>
<td>命令类似 cat ，不过会以一页一页的形式显示，更方便使用者逐页阅读</td>
</tr>
<tr>
<td>less</td>
<td>与 more 类似，但使用 less 可以随意浏览文件，而 more 仅能向前移动，却不能向后移动，而且 less 在查看之前不会加载整个文件</td>
</tr>
<tr>
<td>head</td>
<td>见名知意，显示文件的头部，默认显示前 10 行，如果不止一个文件，则在显示的每个文件前面加一个文件名标题。</td>
</tr>
<tr>
<td>tail</td>
<td>将某个文件最后几行显示在终端上，如果有更新tail会自动刷新，tail -f实时显示追加的内容</td>
</tr>
<tr>
<td>cut</td>
<td>显示每行从开头算起 num1 到 num2 的文字</td>
</tr>
<tr>
<td>split</td>
<td>用于将一个文件分割成数个</td>
</tr>
<tr>
<td>paste</td>
<td>按照行合并内容</td>
</tr>
<tr>
<td>sort</td>
<td>用于将文本文件内容加以排序，sort可针对文本文件的内容，以行为单位来排序。</td>
</tr>
<tr>
<td>uniq</td>
<td>用于检查及删除文本文件中重复出现的行列，一般与 sort 命令结合使用</td>
</tr>
<tr>
<td>wc</td>
<td>统计文件的行数、单词数量或者是字数。（不是卫生间trollface ）</td>
</tr>
<tr>
<td>iconv</td>
<td>转换文件的编码格式</td>
</tr>
<tr>
<td>dos2unix</td>
<td>将Windows格式文件转换为Unix、Linux格式的实用命令</td>
</tr>
<tr>
<td>diff</td>
<td>全拼 difference，最简单的情况下，比较两个文件的不同</td>
</tr>
<tr>
<td>vimdiff</td>
<td>命令行可视化文本对比工具，常用于文本对比合并</td>
</tr>
<tr>
<td>rev</td>
<td>将文件中的每行内容以字符为单位反序输出，即第一个字符最后输出，最后一个字符最先输出，依次类推。</td>
</tr>
<tr>
<td>grep/egrep</td>
<td>过滤字符串，三剑客老三（在文件内查找指定的字符串）</td>
</tr>
<tr>
<td>join</td>
<td>根据相同字段合并两个文件</td>
</tr>
<tr>
<td>tr</td>
<td>转换或删除文件中的字符</td>
</tr>
<tr>
<td>vi/vim</td>
<td>命令文本编辑器（很常用）</td>
</tr>

</table>

### 文件压缩及解压缩命令



<table class="table table-bordered table-striped table-condensed">
<tr>
<td>tar</td>
<td>打包压缩</td>
</tr>
<tr>
<td>unzip</td>
<td>解压文件</td>
</tr>
<tr>
<td>gzip</td>
<td>gzip压缩工具</td>
</tr>
<tr>
<td>zip</td>
<td>压缩工具</td>
</tr>

</table>

### 信息显示命令



<table class="table table-bordered table-striped table-condensed">
<tr>
<td>uname</td>
<td>显示操作系统相关信息的命令</td>
</tr>
<tr>
<td>hostname</td>
<td>设置或者显示系统主机名，没有任何参数就会返回gethostname()函数的返回值</td>
</tr>
<tr>
<td>dmesg</td>
<td>显示开机信息</td>
</tr>
<tr>
<td>uptime</td>
<td>命令告诉你系统启动up了（运行了）多长时间以及系统负载</td>
</tr>
<tr>
<td>stat</td>
<td>用于显示文件或文件系统的详细信息</td>
</tr>
<tr>
<td>du</td>
<td>显示指定的目录或文件所占用的磁盘空间</td>
</tr>
<tr>
<td>df</td>
<td>显示目前在Linux系统上的文件系统的磁盘使用情况统计</td>
</tr>
<tr>
<td>top</td>
<td>实时显示系统中各个进程的资源占用状况，类似于Windows的任务管理器</td>
</tr>
<tr>
<td>free</td>
<td>显示系统内存的使用情况，包括物理内存、交换内存(swap)和内核缓冲区内存</td>
</tr>
<tr>
<td>date</td>
<td>显示或设定系统的日期与时间</td>
</tr>
<tr>
<td>cal</td>
<td>显示指定月份的日历</td>
</tr>

</table>

### 搜索文件命令



<table class="table table-bordered table-striped table-condensed">
<tr>
<td>which</td>
<td>which指令会在环境变量$PATH设置的目录里查找符合条件的文件</td>
</tr>
<tr>
<td>find</td>
<td>查找文件，Linux下非常重要的一条命令，在目录结构中进行搜索。</td>
</tr>
<tr>
<td>whereis</td>
<td>跟which功能相同，但该指令只能用于查找二进制文件、源代码文件和man手册页，一般文件的定位需使用locate命令。</td>
</tr>
<tr>
<td>locate</td>
<td>locate命令要比find -name快得多，原因在于它不搜索具体目录，而是搜索一个数据库/var/lib/mlocate/mlocate.db 。这个数据库中含有本地所有文件信息</td>
</tr>

</table>

### 用户管理命令



<table class="table table-bordered table-striped table-condensed">
<tr>
<td>useradd</td>
<td>添加用户</td>
</tr>
<tr>
<td>usermod</td>
<td>修改用户帐号的各项设定</td>
</tr>
<tr>
<td>userdel</td>
<td>删除用户</td>
</tr>
<tr>
<td>groupadd</td>
<td>添加用户组</td>
</tr>
<tr>
<td>passwd</td>
<td>修改用户密码</td>
</tr>
<tr>
<td>chage</td>
<td>修改用户密码有效期</td>
</tr>
<tr>
<td>id</td>
<td>id会显示用户以及所属群组的实际与有效ID。若两个ID相同，则仅显示实际ID。若仅指定用户名称，则显示目前用户的ID。</td>
</tr>
<tr>
<td>su</td>
<td>切换用户</td>
</tr>
<tr>
<td>vissudo</td>
<td>编辑/etc/sudoers文件的专属命令</td>
</tr>
<tr>
<td>sudo</td>
<td>命令以系统管理者的身份执行指令，也就是说，经由 sudo 所执行的指令就好像是 root 亲自执行。（在 /etc/sudoers 中有出现的使用者）</td>
</tr>

</table>

### 基础网络操作命令



<table class="table table-bordered table-striped table-condensed">
<tr>
<td>telnet</td>
<td>执行telnet指令使用TELNET协议登入远端主机</td>
</tr>
<tr>
<td>ssh</td>
<td>远程登录用于远程登录上Linux主机</td>
</tr>
<tr>
<td>scp</td>
<td>全拼 secure copy，用于不同主机之间复制文件</td>
</tr>
<tr>
<td>wget</td>
<td>命令下载文件</td>
</tr>
<tr>
<td>ping</td>
<td>测试网络主机之间的连通性</td>
</tr>
<tr>
<td>route</td>
<td>显示和设置Linux系统的路由表</td>
</tr>
<tr>
<td>ifconfig</td>
<td>查看、配置、启用或者禁用网络接口的命令。（不要跟Windows的ipconfig记混）</td>
</tr>
<tr>
<td>ifup</td>
<td>启动网卡</td>
</tr>
<tr>
<td>ifdown</td>
<td>关闭网卡</td>
</tr>
<tr>
<td>netstat</td>
<td>查看网络状态</td>
</tr>
<tr>
<td>ss</td>
<td>跟netstat功能相同</td>
</tr>

</table>

### 网络操作命令进阶



<table class="table table-bordered table-striped table-condensed">
<tr>
<td>nmap</td>
<td>全拼 network mapper 是Linux下的网络扫描和嗅探工具包，网络扫描命令</td>
</tr>
<tr>
<td>lsof</td>
<td>全拼 list open files 查看进程打开的文件</td>
</tr>
<tr>
<td>mail</td>
<td>邮件发送和接收命令</td>
</tr>
<tr>
<td>mutt</td>
<td>邮件管理命令</td>
</tr>
<tr>
<td>nslookup</td>
<td>查看DNS信息</td>
</tr>
<tr>
<td>dig</td>
<td>查询DNS包括NS记录，A记录，MX记录等相关信息</td>
</tr>
<tr>
<td>host</td>
<td>查询域名、检查域名解析是否正确</td>
</tr>
<tr>
<td>traceroute</td>
<td>跟踪主机路由</td>
</tr>
<tr>
<td>tcpdump</td>
<td>对网络上的数据包进行截获的包分析工具</td>
</tr>

</table>

### 关于磁盘跟文件系统的命令



<table class="table table-bordered table-striped table-condensed">
<tr>
<td>mount</td>
<td>用于挂载Linux系统外的文件</td>
</tr>
<tr>
<td>umount</td>
<td>可卸除目前挂在Linux目录中的文件系统</td>
</tr>
<tr>
<td>fsck</td>
<td>检查与修复 Linux 档案系统，可以同时检查一个或多个 Linux 档案系统</td>
</tr>
<tr>
<td>dd</td>
<td>指定大小的块拷贝一个文件，并在拷贝的同时进行指定的转换</td>
</tr>
<tr>
<td>dumpe2fs</td>
<td>查看格式化之后的文件系统信息</td>
</tr>
<tr>
<td>dump</td>
<td>使用“备份级别”来实现增量备份，它支持 0～9 共 10 个备份级别（备份分区、文件或目录）</td>
</tr>
<tr>
<td>fdisk</td>
<td>创建和维护分区表，兼容DOS类型的分区表、BSD或者SUN类型的磁盘列表。适用于2TB以下磁盘分区</td>
</tr>
<tr>
<td>parted</td>
<td>规划大小超过2T的分区，也可用于小分区的规划</td>
</tr>
<tr>
<td>mkfs</td>
<td>用来在特定的分区建立Linux文件系统（格式化创建Linux文件系统）</td>
</tr>
<tr>
<td>partprobe</td>
<td>通知操作系统内核分区表更改，通过请求操作系统重新读取分区表</td>
</tr>
<tr>
<td>e2fsck</td>
<td>用于检查使用 Linux ext2 档案系统的 partition 是否正常工作。</td>
</tr>
<tr>
<td>mkswap</td>
<td>创建交换分区</td>
</tr>
<tr>
<td>swapon</td>
<td>启用交换分区</td>
</tr>
<tr>
<td>swapoff</td>
<td>关闭交换分区</td>
</tr>
<tr>
<td>sync</td>
<td>用于数据同步,sync命令是在关闭Linux系统时使用的（将内存的数据写入磁盘）</td>
</tr>
<tr>
<td>resize2fs</td>
<td>调整ext文件系统的空间大小</td>
</tr>

</table>

### 关于用户授权跟系统权限的命令



<table class="table table-bordered table-striped table-condensed">
<tr>
<td>chmod</td>
<td>修改文件或者目录权限</td>
</tr>
<tr>
<td>chown</td>
<td>利用 chown 将指定文件的拥有者改为指定的用户或组</td>
</tr>
<tr>
<td>chgrp</td>
<td>使用chgrp指令取变更文件与目录所属群组（更改文件用户组）</td>
</tr>
<tr>
<td>umask</td>
<td>指定在建立文件时预设的权限掩码（显示或者隐藏）</td>
</tr>

</table>

### 查看系统用户登录信息命令



<table class="table table-bordered table-striped table-condensed">
<tr>
<td>whoami</td>
<td>用于显示自身用户名称，相当于执行id -un命令</td>
</tr>
<tr>
<td>who</td>
<td>用于显示系统中有哪些使用者正在上面，显示的资料包含了使用者 ID、使用的终端机、从哪边连上来的、上线时间、呆滞时间、CPU 使用量、动作等等。</td>
</tr>
<tr>
<td>w</td>
<td>执行这项指令可得知目前登入系统的用户有哪些人，以及他们正在执行的程序。</td>
</tr>
<tr>
<td>last</td>
<td>显示近期用户或终端的登录情况</td>
</tr>
<tr>
<td>lastlog</td>
<td>检查某用户上次登录时间</td>
</tr>
<tr>
<td>users</td>
<td>显示当前登录系统的所有用户</td>
</tr>
<tr>
<td>finger</td>
<td>用来查找并显示用户信息，系统管理员通过使用该命令可以知道某个时候到底有多少用户在使用这台Linux主机。</td>
</tr>

</table>

### 内置命令及其他



<table class="table table-bordered table-striped table-condensed">
<tr>
<td>echo</td>
<td>用于字符串的输出</td>
</tr>
<tr>
<td>printf</td>
<td>主要作用是输出文本，按照我们指定的格式输出文本</td>
</tr>
<tr>
<td>rpm</td>
<td>RPM软件包的管理工具</td>
</tr>
<tr>
<td>yum</td>
<td>是一个在Fedora和RedHat以及SUSE中的Shell前端软件包管理器</td>
</tr>
<tr>
<td>watch</td>
<td>可以监测一个命令的运行结果</td>
</tr>
<tr>
<td>alias</td>
<td>设置系统别名</td>
</tr>
<tr>
<td>unalias</td>
<td>取消系统别名</td>
</tr>
<tr>
<td>date</td>
<td>查看或者设置系统时间</td>
</tr>
<tr>
<td>clear</td>
<td>清屏</td>
</tr>
<tr>
<td>history</td>
<td>查看命令执行的历史记录</td>
</tr>
<tr>
<td>eject</td>
<td>弹出光驱</td>
</tr>
<tr>
<td>time</td>
<td>获取到一个程序的执行时间</td>
</tr>
<tr>
<td>nc</td>
<td>实现任意TCP/UDP端口的侦听，nc可以作为server以TCP或UDP方式侦听指定端口（功能强大的网络工具）</td>
</tr>
<tr>
<td>xargs</td>
<td>给命令传递参数的一个过滤器，也是组合多个命令的一个工具</td>
</tr>
<tr>
<td>exec</td>
<td>调用并执行指令的命令</td>
</tr>
<tr>
<td>export</td>
<td>设置或者显示环境变量</td>
</tr>
<tr>
<td>unset</td>
<td>unset为shell内建指令，可删除变量或函数</td>
</tr>
<tr>
<td>type</td>
<td>一般情况下，type命令被用于判断另外一个命令是否是内置命令，但是它实际上有更多的用法</td>
</tr>
<tr>
<td>bc</td>
<td>命令行科学计算器</td>
</tr>

</table>

### 系统管理与性能监视命令



<table class="table table-bordered table-striped table-condensed">
<tr>
<td>chkconfig</td>
<td>管理Linux系统开机启动项</td>
</tr>
<tr>
<td>vmstat</td>
<td>全拼 virtual meomory statistics (虚拟内存缩写)虚拟内存统计</td>
</tr>
<tr>
<td>mpstat</td>
<td>mpstat是 Multiprocessor Statistics的缩写，是实时系统监控工具</td>
</tr>
<tr>
<td>iostat</td>
<td>iostat工具将对系统的磁盘操作活动进行监视</td>
</tr>
<tr>
<td>sar</td>
<td>全拼 system activity reporter（系统活动情况报告）是目前 Linux 上最为全面的系统性能分析工具之一，可以从多方面对系统的活动进行报告，包括：文件的读写情况、 系统调用的使用情况、磁盘I/O、CPU效率、内存使用状况、进程活动及IPC有关的活动等</td>
</tr>
<tr>
<td>ipcs</td>
<td>提供关于一些进程间通信方式的信息，包括共享内存，消息队列，信号</td>
</tr>
<tr>
<td>ipcrm</td>
<td>删除消息队列、信号集、或者共享内存标识</td>
</tr>
<tr>
<td>strace</td>
<td>strace能帮助你追踪到一个程序所执行的系统调用</td>
</tr>
<tr>
<td>ltrace</td>
<td>用来跟踪进程调用库函数的情况</td>
</tr>

</table>

### 关机\重启\注销和查看系统信息命令



<table class="table table-bordered table-striped table-condensed">
<tr>
<td>shutdown</td>
<td>关机</td>
</tr>
<tr>
<td>halt</td>
<td>与shutdown功能相同</td>
</tr>
<tr>
<td>poweroff</td>
<td>关闭电源</td>
</tr>
<tr>
<td>logout</td>
<td>退出系统</td>
</tr>
<tr>
<td>exit</td>
<td>退出目前的shell</td>
</tr>
<tr>
<td>ctrl+d</td>
<td>退出当前登录的Shell的快捷键</td>
</tr>

</table>

### 进程管理命令



<table class="table table-bordered table-striped table-condensed">
<tr>
<td>bg</td>
<td>将一个在后台暂停的命令，变成继续执行</td>
</tr>
<tr>
<td>fg</td>
<td>将后台中的命令调至前台继续运行</td>
</tr>
<tr>
<td>jobs</td>
<td>将当前的程序挂载</td>
</tr>
<tr>
<td>kill</td>
<td>发送指定的信号到相应进程</td>
</tr>
<tr>
<td>killall</td>
<td>通过进程名终止进程</td>
</tr>
<tr>
<td>pkill</td>
<td>给正在运行的程序进程发送信号</td>
</tr>
<tr>
<td>crontab</td>
<td>定时任务命令</td>
</tr>
<tr>
<td>ps</td>
<td>显示进程快照</td>
</tr>
<tr>
<td>pstree</td>
<td>通过树形结构显示进程</td>
</tr>
<tr>
<td>nice/renice</td>
<td>调整程序运行时的优先级</td>
</tr>
<tr>
<td>nohup</td>
<td>可以将以忽略挂起信号的方式运行起来，被运行的程序的输出信息将不会显示到终端</td>
</tr>
<tr>
<td>pgrep</td>
<td>查找匹配条件的进程</td>
</tr>
<tr>
<td>runlevel</td>
<td>查看系统当前运行的级别</td>
</tr>
<tr>
<td>init</td>
<td>切换运行级别</td>
</tr>
<tr>
<td>service</td>
<td>用于对系统服务进行管理，比如启动（start）、停止（stop）、重启（restart）、查看状态（status）等。</td>
</tr>

</table>

### 后记

  将比较常用的Linux命令整理归纳出来了！有错误的地方还望大家指正，如果还有其他的常用命令，大家可以在评论区留言进行补充。
