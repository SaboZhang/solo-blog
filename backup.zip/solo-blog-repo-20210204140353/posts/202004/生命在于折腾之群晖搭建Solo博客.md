title: 生命在于折腾之群晖搭建Solo博客
date: '2020-04-14 00:30:33'
updated: '2020-04-14 00:30:33'
tags: [Solo]
permalink: /synology
---
![](https://img.hacpai.com/bing/20190116.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

&emsp;&emsp;在上一篇[博客](https://www.taosugar.com/articles/2020/04/05/1586087934810.html)想了解的可以去看我上一篇[Solo博客搭建之路](https://www.taosugar.com/articles/2020/04/05/1586087934810.html)。博客中为大家介绍了Solo博客在Ubuntu18.04上搭建博客的两种方式，Tomcat部署跟Docker部署，今天来跟大家一起折腾群晖安装Solo博客以及群晖内网穿透。有兴趣的可以折腾一下，过程比较简单。

## 一、搭建准备

1. 支持docker的群晖一台（黑白群晖都可以）
2. 注册ZeroTier（免费内网穿透使用，后面为大家介绍使用方式以及下载地址）
3. 没有了吧 哈哈哈哈（挖个坑:trollface: ）

## 二、开始搭建

  看到这了我想你应该已经有群晖了，并且已经安装好Docker了吧！！！如果没装好，那就打开群晖套件中心，然后在搜索框输入Docker直接安装就可以，如下图所示。<div align="center">![QQ截图20200413210512.png](https://img.hacpai.com/file/2020/04/QQ%E6%88%AA%E5%9B%BE20200413210512-c32d134c.png)
  Docker安装</div>&emsp;&emsp;Docker安装完之后双击打开Docker然后点开注册表，之后在搜索框输入Solo然后搜索，第一个就是本集主角Solo博客系统，双击就可以下载，如下图所示:<center>![QQ截图20200413211042.png](https://img.hacpai.com/file/2020/04/QQ%E6%88%AA%E5%9B%BE20200413211042-54c8cec7.png)步骤截图</center>之后静候几分钟就下载下来了，然后我们打开映像位置，双击之后进入配置模式然后点击高级设置<center>![QQ截图20200413212748.png](https://img.hacpai.com/file/2020/04/QQ%E6%88%AA%E5%9B%BE20200413212748-89f31825.png)
步骤![QQ截图20200413212830.png](https://img.hacpai.com/file/2020/04/QQ%E6%88%AA%E5%9B%BE20200413212830-51dfa921.png)
高级设置</center>&emsp;&emsp;进入高级设置之后我们逐项进行设置，第一项“高级设置”两个复选框就是字面意思，没有什么特别的意思，下面单选框在选择创建桌面快捷方式时可以进行更改，网页就是我们点击桌面图标可以跳转的地方，一般无所谓不需要更改，毕竟后续还是通过浏览器去访问的。<center>![QQ截图20200413220926.png](https://img.hacpai.com/file/2020/04/QQ%E6%88%AA%E5%9B%BE20200413220926-62361c3c.png)高级设置</center>&emsp;&emsp;“卷”添加映射文件夹，如果要安装第三方主题可以进行映射，点击添加文件夹-->选择要放主题的文件夹—>映射目录`/opt/solo/skins/`也就是运行solo执行的皮肤挂载命令中的冒号后的后半部分命令就是映射的路径。<center>![QQ截图20200413221151.png](https://img.hacpai.com/file/2020/04/QQ%E6%88%AA%E5%9B%BE20200413221151-e497b30c.png)
卷</center>&emsp;&emsp;“网络”如果将左下角的使用与Docker Host相同的网络勾选上就不需要再设置后面的端口映射。该选项等同于在其他系统中运行docker的`--network=host`<center>![QQ截图20200413222214.png](https://img.hacpai.com/file/2020/04/QQ%E6%88%AA%E5%9B%BE20200413222214-13575883.png)
网络</center>&emsp;&emsp;“端口设置”设置映射的端口，也就是本地的访问方式，比如要在本地直接通过域名或者IP去访问那本地端口就设置成 80 （如果在网络中选择了与Docker Host相同的网络就不需要再进行此次设置）<center>![QQ截图20200413222412.png](https://img.hacpai.com/file/2020/04/QQ%E6%88%AA%E5%9B%BE20200413222412-da6e55b6.png)端口</center>&emsp;&emsp;“链接”此项此处用不上不做介绍。“环境”此处是重点！！！如图所示：<center>![QQ截图20200413221655.png](https://img.hacpai.com/file/2020/04/QQ%E6%88%AA%E5%9B%BE20200413221655-e0af4a30.png)
环境配置</center>&emsp;&emsp;点击加号进行可变变量的设置，此处相当于启动docker所带的参数。其中“可变”那一栏填写=号前面的命令，值填引号中的内容，启动命令如下：

```
docker run --detach --name solo --network=host \
	--env RUNTIME_DB="MYSQL" \
	--env JDBC_USERNAME="root" \
	--env JDBC_PASSWORD="admin123" \
	--env JDBC_DRIVER="com.mysql.cj.jdbc.Driver" \
	--env JDBC_URL="jdbc:mysql://127.0.0.1:3306/solo?useUnicode=yes&characterEncoding=UTF-8&useSSL=false&serverTimezone=UTC&allowPublicKeyRetrieval=true" \
    b3log/solo --listen_port=8080 --server_scheme=http --server_host=localhost --server_port=
#将该运行命令中的输入“可变”跟值当中 例如：可变中输入RUNTIME_DB那就在值中输入MYSQL不需要填入标点符号跟--env 将所有需要传递的参数一一填入即可之后直接点应用即可。后面的值如果为空不填写就可以。此处直接从第二行的命令开始即可。
```
完成以上工作之后点击应用即可启动程序，然后在本地访问群晖IP+端口号即可访问，但是此处有坑，没有说数据库的安装:trollface: MySQL数据库的安装在群晖上也很简单，跟上面一样在注册表搜索MySQL然后选择需要的版本进行安装，这块有详细教程，大家可以[看这里](https://blog.csdn.net/lzyy1992/article/details/86256019)因为我使用的跟我现在的博客用的是同一个个数据库，所以我在此处省略了数据库的步骤，看到此处如果起不来，那就停止solo程序的docker，然后安装MySQL后再重新启动Solo的容器即可打开博客。
## 三、外网访问
&emsp;&emsp;经过上面的步骤之后我们的Solo博客就已经搭建好，但是并不能在局域网之外访问，如果你是个玩群晖的大佬，我想你应该已经可以外网访问了，并且知道我接下来要说什么。如果你还不知道如何让群晖在外网访问，那么请接着往下看我慢慢道来。
### 1.公网穿透
这种穿透的前期条件是你的网络有固定IP，那么一切都很好办，你博客的访问速度取决于你群晖的上传带宽，具体的配置方式大家[看这个教程](https://blog.csdn.net/u011580177/article/details/97037025)吧，困了😫 就不写这个的配置教程了（此时内心OS不想填坑了）。
### 2.使用花生壳
花生壳免费的只有1M带宽2GB流量还限制带宽，表示写博客根本不够用啊。还限制端口，而付费服务贵的吓人，如果只做体验可以考虑一下，[这里是教程](http://service.oray.com/question/4615.html)
### 3.群晖frp穿透
使用frp内网穿透工具使处于内网中的电脑能够像访问公网电脑一样方便，比如将公司或个人电脑里面的web项目让别人能够访问以便于自己及时修改，或者是进行远程或ssh连接。frp的项目一直是开源的支持 tcp, udp, http, https 协议[官方项目地址](https://github.com/fatedier/frp)，大家感兴趣可以先看看，这个是[网上的教程](http://www.gebi1.com/thread-283729-1-1.html?_dsign=818f37c5)，今天暂时不介绍这个，想玩这个的可以评论留言，如果感兴趣的人多了，下篇文章给大家填坑。
### ZeroTier内网穿透
&emsp;&emsp;这个穿透工具的优点是免费，官方的介绍是这个是通过P2P传输，所以速度也不错，但是有的地方网络并不能实现P2P 国情如此。下面为大家介绍一下这个工具的具体教程吧，先填个小坑。ZeroTier设备支持：免费用户可以支持100个设备，支持Windows、macOS、Linux、IOS、Android、Synology、QNAP、Western Digital MyCloud NAS等等。但是这个的缺点是只能在安装客户端的机器上访问，也就是只能方便自己在别的地方访问博客（大家别骂我，这个其实还是只有自己可以看到自己的博客）下篇为大家介绍frp的穿透就可以任意访问了，并且不受条件限制。前提是大家需要了解的话 = = 好了，接着说这个，首先访问[官网](https://www.zerotier.com/)找最后一个my.zerotier.com然后点进去然后注册一个账号，我想注册账号应该不用一步一步的说吧，如果需要下面评论留言，我给截图😂 第二步登陆刚注册的账号，进去之后点击networks，然后点击` Create a Network`再次点击下面新出现的字符串进入配置页面。 Basics设置中建议选择默认的`PRIVATE`私有网卡Advanced选择你想要的IP段。至此在这个页面就配置完了，暂时先不要关闭页面，后面还会用到。
&emsp;&emsp;首先打开[官网](https://www.zerotier.com/)点击download 找到Synology NAS然后点击进入下载页面，选择跟自己硬件相匹配的.spk安装包，之后打开群晖的套件中心，将安装包上传安装。<center>![20190712114108186.gif](https://img.hacpai.com/file/2020/04/20190712114108186-8b32f730.gif)安装</center>群晖安装完之后返回之前的配置页面在Basics里面将networkID复制出来，然后返回群晖界面。<center>![20190712114539326.gif](https://img.hacpai.com/file/2020/04/20190712114539326-f666681a.gif)添加ID</center>将ID join进去，然后再返回到ZeroTier/network页面里，查看新设备，然后勾选。<center>![20190712115046131.gif](https://img.hacpai.com/file/2020/04/20190712115046131-9a6e3c03.gif)授权</center>群晖客户端到这里就添加完成了。然后就是在要访问群晖的客户端安装。直接还是在官网的downloads页面下载对应安装包进行安装就可以，此处windows举例。同样在下载页面下载windows版本的安装包，然后在windows下执行安装<center>![20190712110039426.gif](https://img.hacpai.com/file/2020/04/20190712110039426-c069bc37.gif)执行安装</center>同样的在系统托盘区域，邮件打开，然后跟群晖步骤一样，复制ID然后进行join。之后再返回页面进行授权。<center>![20190712111428861.gif](https://img.hacpai.com/file/2020/04/20190712111428861-1b31593c.gif)授权</center>至此就可以在安装ZeroTier的客户端进行穿透访问了群晖了。也可以通过这个IP访问我们在群晖docker上搭建的Solo博客。
## 后记
&emsp;&emsp;可能写的不是很好，如果大家发现有不对的地方欢迎大家指出。有什么问题或者疑问，在下方评论留言吧，希望大家多多支持我，谢谢！！！





