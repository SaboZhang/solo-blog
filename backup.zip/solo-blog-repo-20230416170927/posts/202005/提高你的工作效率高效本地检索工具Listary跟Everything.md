title: 提高你的工作效率，高效本地检索工具Listary跟Everything
date: '2020-05-03 16:59:35'
updated: '2020-05-03 20:07:22'
tags: [软件分享]
permalink: /searching
---
![](https://img.hacpai.com/bing/20191105.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

  正在刷漫威的途中，朋友发来消息说Wndows7的搜索功能不好使了。Window7的搜索相信大家都有所体验。本地搜索功能速度之慢让人无力吐槽（不知道他是怎么一直用的这个让人无力吐槽的自带搜索功能的）。也没想太多就开始着手帮忙解决问题，然而毕竟国内大环境如此，朋友使用的Ghost版的Windows7，指导一个电脑小白去在这样的系统上去解决问题，简直不要太麻烦！:wulian:

  既然问题找上门来了，总不能不帮忙解决吧！幸好，这个世上牛人多，神人们也多，制作了一个又一个的神器，着实提升了我等P民的工作效率和生活质量。最终为他提供了一种代替的解决方案，也就是今天要为大家推荐的高效检索工作之一的[Everything](https://www.voidtools.com/zh-cn/ "点击直达官网")，解决了本地检索的问题。别问为什么一开始不直接推荐，而是折腾半天之后才给出替代方案的，因为我想的是尽量不改变别人的工作方式，毕竟软件也是需要简单学习一下高效使用方式的！废话有点过多了，下面开始为大家介绍这我使用比较多的两款高效搜索工具[Everything](https://www.voidtools.com/zh-cn/ "点击直达官网")跟[Listary](https://www.listary.com/ "点击直达官网")。

## Listary是什么？

  Listary在维基百科中是这样介绍的：

> **Listary**是一款用于[Windows](https://zh.wikipedia.org/wiki/Microsoft_Windows "Microsoft Windows")的文件名定位/搜索辅助软件。它为Windows传统低效的文件打开/保存对话框提供了便捷、人性化的文件（夹）定位方式，同时改善了常见[文件管理器](https://zh.wikipedia.org/wiki/%E6%96%87%E4%BB%B6%E7%AE%A1%E7%90%86%E5%99%A8 "文件管理器")中文件夹切换的效率。
>
>   与Everything的比较
>
>   许多用户都将Listary与Everything进行比较甚至视为同类软件，实际上从前面的功能说明可以看出它们除了创建索引的方法相似外，实际上几乎没有共同点。例如两者的定位：Everything的定位为替代传统的本地搜索工具，如[Google桌面](https://zh.wikipedia.org/wiki/Google%E6%A1%8C%E9%9D%A2 "Google桌面")，Listary则为基于搜索的文件定位与操作和文件夹切换辅助工具。

## 为什么用Listary

  工欲善其事，必先利其器，得益于Windows对NTFS的支持并利用了Windows提供的API支持获取所有文件列表，能输入瞬间返回全盘的匹配文件，且功能丰富，上手简单。打个比方：你同时几天前发给你一些文档，你直接接收了。当你要用的时候放在哪了发现没一点印象，但是你大概记住了文件的名字，那么你只需要按下两次Ctrl键，弹出搜索框输入你记住的名字，就可以检索出所有的包含你输入的这个文件名字的所有文件。<div style="text-align:center">![1.gif](https://img.hacpai.com/file/2020/05/1-06ef1bbb.gif)</div>

可以看到瞬间列出了所有跟检索文字有关的文件。如果你是因为懒散不知道将文件放到何处了，那么这款软件就能很好的解决这个问题。当然Listary的强大之处冰不止这些，除了可以本地检索快速定位文件，还可以在桌面直接进行文件搜索。![2.gif](https://img.hacpai.com/file/2020/05/2-292de0e7.gif)</div>

除了在本地搜索以外，还可以直接进行百度或者Google等搜索引擎的检索，更多功能大家可去深入发掘，比如可以自定义快捷键直接进行淘宝商品检索等。Listary还退出了Pro版本，需要付费，个人觉得免费版已经可以应付日常使用了，没有必要非上专业版。Pro版本中增加了文件工作流，如果不是深度使用此软件，免费版本主可以应付。[这里查看区别](https://www.listary.com/pro "点击直达官网")

![3.gif](https://img.hacpai.com/file/2020/05/3-0cdd6315.gif)</div>

## Everything是什么？

  关于Everything的介绍同样的给大家搬运一下维基百科的介绍：

> **  Everything**是一个[私有的](https://zh.wikipedia.org/wiki/%E4%B8%93%E6%9C%89%E8%BD%AF%E4%BB%B6 "专有软件")[免费](https://zh.wikipedia.org/wiki/%E5%85%8D%E8%B4%B9%E8%BD%AF%E4%BB%B6 "免费软件")Windows[桌面搜索引擎](https://zh.wikipedia.org/wiki/%E6%A1%8C%E9%9D%A2%E6%90%9C%E7%B4%A2 "桌面搜索")，可以在[NTFS](https://zh.wikipedia.org/wiki/NTFS "NTFS")卷上快速地根据名称查找文件和目录。由澳大利亚人大卫·卡彭特（David Carpenter）开发。2009年10月30日，在拥有70,000用户的[Wakoopa](https://zh.wikipedia.org/wiki/Wakoopa "Wakoopa")网站排名中，Everything在1757个应用程序中排名第857，超越了老牌压缩工具[WinZip](https://zh.wikipedia.org/wiki/WinZip "WinZip")。直到2013年，Everything仍处于开发状态。

## 为什么用Everything？

  Everything非常小巧，安装包仅有1.3M，运行时占用资源也极低。搜索速度非常快，Windows10搜索一个文件1分钟之后找出了3个文件，并且还在继续搜索。而Everything搜索仅用了1秒。并且Everyting这款软件完全免费。同时软件还提供便携版本的下载，该软件首次使用会建立一次索引，大概几秒钟的时间，建立完成之后就可以进行本地化的快速检索。![5.gif](https://img.hacpai.com/file/2020/05/5-2df0b03e.gif)</div>

  Everything能在 Windows XP、Vista、Windows 7、Windows 8 和 Windows 10 上运行。NTFS 索引功能需要 Everything 服务或用管理员方式打开 Everything。更多的使用方式大家可以查看官网的[帮助文档](https://www.voidtools.com/zh-cn/support/everything/ "点击直达")

## 下载地址

Listary下载地址：[官网下载](https://www.listary.com/download "点击直达")  [百度云](https://pan.baidu.com/s/1t3H0GlyE2LCesZYXFZkm9g "点击直达")  提取码：ulqp

Everything下载地址：[官网下载](https://www.voidtools.com/zh-cn/downloads/ "点击直达")  [百度云](https://pan.baidu.com/s/1t3H0GlyE2LCesZYXFZkm9g "点击直达")  提取码：ulqp

## 后记

  高效办公的工具有很多，这里为大家推荐了这两款高效搜索的软件，虽然现在Windows的搜索有了很大的进步，但是效率还是没有这两款软件高，当然检索工具远不止这两个，还有更多的高效软件等着大家去发掘。我推荐的这两款软件的区别主要在于Everything侧重于文件搜索，Listary侧重于文件定位，前者适合电脑党，后者更适合文件深度管理用户。
